// Copyright ©2018 The Gonum Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Package errors provides generated internal error functions for DOT parsing.
package errors // import "gonum.org/v1/gonum/graph/formats/dot/internal/errors"
